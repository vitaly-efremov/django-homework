#-*- coding: utf-8 -*-
from random import randint
from django.views.generic.base import TemplateView


class IndexView(TemplateView):
    template_name = "index.html"

    def get_context_data(self, **kwargs):
        context = super(IndexView, self).get_context_data(**kwargs)
        statistict_stud = []
        students = Student([1, 2, 3, 4, 5, 6, 7, 8, 9, 10], ['Иванов', 'Петров', 'Федоров', 'Викторов', 'Шишкин', 'Романов', 'Ковунов', 'Герасимов', 'Сычев', 'Ерохин'])
        subject = Subject(['s1', 's2', 's3', 's4', 's5'])
        score = Score([[randint(1,5), randint(1,5), randint(1,5), randint(1,5), randint(1,5)], [randint(1,5), randint(1,5), randint(1,5), randint(1,5), randint(1,5)], [randint(1,5), randint(1,5), randint(1,5), randint(1,5), randint(1,5)], [randint(1,5), randint(1,5), randint(1,5), randint(1,5), randint(1,5)], [randint(1,5), randint(1,5), randint(1,5), randint(1,5), randint(1,5)],
                   [randint(1,5), randint(1,5), randint(1,5), randint(1,5), randint(1,5)], [randint(1,5), randint(1,5), randint(1,5), randint(1,5), randint(1,5)], [randint(1,5), randint(1,5), randint(1,5), randint(1,5), randint(1,5)], [randint(1,5), randint(1,5), randint(1,5), randint(1,5), randint(1,5)], [randint(1,5), randint(1,5), randint(1,5), randint(1,5), randint(1,5)]],
                   [1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
        for i in range(1,11):
            statistics = Statistics(score.get_rez(i))
            statistict_stud.append(statistics.formatter(i, students.get_fio(i), subject.get_subject()))
        bad_stud = ', '.join(students.get_fio(i) for i in score.bad_student())
        excellent_stud = ', '.join(students.get_fio(i) for i in score.excellent_student())
        
        context.update(
            {
                'students_statistics': statistict_stud,
                'excellent_students': excellent_stud,
                'bad_students': bad_stud
            }
        )
        return context


class Student(object):
    def __init__(self, s_num, fio):
        self.student = dict(zip(s_num, fio))
        
    def get_fio(self, s_num):
        return self.student.setdefault(s_num)

class Subject(object):
    def __init__(self, subject):
        self.subject = subject
    def get_subject(self):
        return self.subject
    
class Score(object):
    def __init__(self, rez, s_num):
        self.student_marks = dict(zip(s_num, rez))
        
    def get_rez(self, s_num):                   
        return self.student_marks[s_num]
    
    def bad_student(self):
        return [i[0] for i in self.student_marks.items() if i[1].count(2) != 0]
    
    def excellent_student(self):
        return [i[0] for i in self.student_marks.items() if ((i[1].count(3) == 0) and (i[1].count(2) == 0))]  

class Statistics(object):
    def __init__(self, rez):
        self.rez = rez
        
    def _average_grade(self):
        return float(sum(self.rez))/len(self.rez)
    
    def formatter(self, s_num, fio, subject):
        data = {'id':s_num, 'fio':fio}
        foo = dict(zip(subject, self.rez))
        data.update(foo)
        data.update({'average':self._average_grade()})
        return data

  

